Can you find the largest file?  Submit it as: flag{file_name}
